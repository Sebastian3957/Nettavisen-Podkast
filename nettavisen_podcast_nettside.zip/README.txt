NETTAVISEN-STYLE PODCASTSIDE

1. Åpne index.html i Chrome/Edge.
2. Trykk «Velg podcastvideo fra PC-en» for å teste deres video.
3. Endre overskrift, ingress, dato og tekst direkte i index.html.
4. For en ferdig versjon kan dere legge videoen i samme mappe og koble den til video-elementet.

Siden er laget som en skoleprosjekt-mockup inspirert av layouten i referansebildet:
svart bakgrunn, stor Nettavisen-lignende topptekst, bred videospiller og kort artikkeltekst under.
